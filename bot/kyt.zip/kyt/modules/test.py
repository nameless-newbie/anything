from kyt import *

@bot.on(events.NewMessage(pattern=r"(?:.test|/test)$"))
@bot.on(events.CallbackQuery(data=b'start'))
async def start(event):
	inline = [
[Button.url("CONTACT TELEGRAM","https://t.me/kuzavpn")],
[Button.url("CONTACT WHATSAPP","https://wa.me/628971173434")]]
	sender = await event.get_sender()
	val = valid(str(sender.id))
	if val == "false":
		try:
			await event.answer("```ID ANDA TIDAK TERDAFTAR```", alert=True)
		except:
			await event.reply("```ID ANDA TIDAK TERDAFTAR```")
	elif val == "true":
		msg = f"""
```ID ANDA TERDAFTAR```
"""
		x = await event.edit(msg,buttons=inline)
		if not x:
			await event.reply(msg,buttons=inline)





